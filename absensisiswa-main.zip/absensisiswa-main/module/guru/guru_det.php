<?php
include "config/conn.php";
?>

<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header"><strong>Input Guru</strong></h3>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Edit Data Guru
            </div>
            <div class="panel-body">
                <div class="row">
                    <?php
                    // Menggunakan mysqli_query untuk menggantikan mysql_query
                    $sql = mysqli_query($conn, "SELECT * FROM guru WHERE nip='$_SESSION[idu]'");
                    $rs = mysqli_fetch_array($sql);
                    ?>
                    <form method="post" role="form" action="././module/simpan.php?act=guru_det">
                        <input type="hidden" name="idg" value="<?php echo $rs['idg']; ?>" />
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>NIP</label><br>
                                <label><?php echo $rs['nip']; ?></label>
                            </div>
                            <div class="form-group">
                                <label>Nama</label>
                                <input class="form-control" placeholder="Nama" name="nama" value="<?php echo $rs['nama']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <?php if ($rs['jk'] == "L") { ?>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="jk" value="L" checked> Laki - Laki
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="jk" value="P"> Perempuan
                                        </label>
                                    </div>
                                <?php } else { ?>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="jk" value="L"> Laki - Laki
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="jk" value="P" checked> Perempuan
                                        </label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Alamat</label>
                                <textarea class="form-control" placeholder="Alamat" name="alamat" rows="3"><?php echo $rs['alamat']; ?></textarea>
                            </div>

                            <div class="form-group">
                                <label>Ganti Password</label>
                                <input class="form-control" placeholder="Password Baru" name="pass" type="password">
                            </div>
                            <br>
                            <button type="submit" class="btn btn-success">Simpan</button>
                        </div>
                        <!-- /.col-lg-6 (nested) -->
                    </form>
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
